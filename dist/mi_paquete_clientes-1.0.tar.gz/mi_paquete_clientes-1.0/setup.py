from setuptools import setup

setup(
    name='mi_paquete_clientes',
    version='1.0',
    description='Segunda pre-entrega',
    author='Javier Pires',
    author_email='javierpires30@gmail.com',
    packages=['clientes']      
)